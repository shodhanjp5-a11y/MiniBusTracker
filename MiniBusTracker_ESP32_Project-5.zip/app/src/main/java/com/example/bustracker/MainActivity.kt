package com.example.bustracker

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.InputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var currentStop: TextView
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null

    // Standard Serial Port Profile UUID used by many Bluetooth serial modules.
    private val sppUuid: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        currentStop = findViewById(R.id.currentStop)

        findViewById<Button>(R.id.demo1).setOnClickListener { showStop("STOP1") }
        findViewById<Button>(R.id.demo2).setOnClickListener { showStop("STOP2") }
        findViewById<Button>(R.id.demo3).setOnClickListener { showStop("STOP3") }
        findViewById<Button>(R.id.connect).setOnClickListener { connectToPairedEsp32() }
    }

    private fun showStop(message: String) {
        val stop = when (message.trim().uppercase()) {
            "STOP1" -> "Stop 1"
            "STOP2" -> "Stop 2"
            "STOP3" -> "Stop 3"
            else -> message.trim()
        }
        currentStop.text = "Current Stop: $stop"
        status.text = "Bus detected at $stop"
    }

    private fun connectToPairedEsp32() {
        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                100
            )
            return
        }

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            status.text = "Bluetooth not supported"
            return
        }

        val device: BluetoothDevice? =
            adapter.bondedDevices.firstOrNull {
                it.name?.contains("ESP32", ignoreCase = true) == true
            }

        if (device == null) {
            status.text = "Pair ESP32 first, then tap Connect"
            return
        }

        Thread {
            try {
                socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket!!.connect()
                input = socket!!.inputStream
                runOnUiThread { status.text = "ESP32 connected" }
                listen()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Connection failed: ${e.message}" }
            }
        }.start()
    }

    private fun listen() {
        val buffer = ByteArray(256)
        val data = StringBuilder()

        try {
            while (true) {
                val n = input?.read(buffer) ?: break
                data.append(String(buffer, 0, n))
                while (data.contains("\n")) {
                    val line = data.substringBefore("\n").trim()
                    data.delete(0, data.indexOf("\n") + 1)
                    if (line.isNotEmpty()) runOnUiThread { showStop(line) }
                }
            }
        } catch (_: Exception) {
            runOnUiThread { status.text = "ESP32 disconnected" }
        }
    }
}
