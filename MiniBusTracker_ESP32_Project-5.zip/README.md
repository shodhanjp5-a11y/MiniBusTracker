# Mini Bus Tracker — ESP32 + RFID

This is a starter Android project for a college mini-project demonstration.

## Demo
1. Build/install the Android app.
2. The app has three demo buttons so you can test Stop 1, Stop 2 and Stop 3 immediately.
3. Later pair the phone with the ESP32 named `MiniBusESP32`.
4. The app looks for a paired Bluetooth device whose name contains `ESP32`.
5. ESP32 sends `STOP1`, `STOP2`, or `STOP3` when the RFID reader detects the corresponding stop tag.

## Hardware
- ESP32 development board
- RC522 RFID reader
- 3 RFID cards/tags
- Optional IR sensor for additional bus/line detection
- Toy bus
- Battery/power bank
- Jumper wires and breadboard

## Android build
Open this project in Android Studio or an Android Gradle-compatible IDE, sync Gradle, then build the debug APK.

## Important
The example RFID UIDs in the Arduino sketch are placeholders. Replace them with the actual UIDs of your three RFID tags.

For the physical demo, put one RFID tag at each of the three stops and the RC522 reader on the toy bus.
