/*
  MINI BUS TRACKER
  ESP32 + RFID RC522

  Put one RFID tag at each stop:
  STOP 1 tag -> UID below
  STOP 2 tag -> UID below
  STOP 3 tag -> UID below

  Replace the example UIDs after reading your actual cards/tags.

  The ESP32 sends:
    STOP1
    STOP2
    STOP3
  over Bluetooth Serial.

  Note: This sketch uses Bluetooth Classic Serial (SPP).
*/

#include <BluetoothSerial.h>
#include <SPI.h>
#include <MFRC522.h>

BluetoothSerial SerialBT;

#define SS_PIN 5
#define RST_PIN 22

MFRC522 rfid(SS_PIN, RST_PIN);

// Replace these with the UIDs of your 3 RFID tags.
String stop1UID = "DE AD BE EF";
String stop2UID = "11 22 33 44";
String stop3UID = "AA BB CC DD";

void setup() {
  Serial.begin(115200);
  SerialBT.begin("MiniBusESP32");

  SPI.begin();
  rfid.PCD_Init();

  Serial.println("Mini Bus Tracker ready");
  SerialBT.println("READY");
}

void loop() {
  if (!rfid.PICC_IsNewCardPresent()) return;
  if (!rfid.PICC_ReadCardSerial()) return;

  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (i > 0) uid += " ";
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();

  Serial.println("RFID: " + uid);

  if (uid == stop1UID) {
    SerialBT.println("STOP1");
    Serial.println("STOP1");
  } else if (uid == stop2UID) {
    SerialBT.println("STOP2");
    Serial.println("STOP2");
  } else if (uid == stop3UID) {
    SerialBT.println("STOP3");
    Serial.println("STOP3");
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
  delay(1500);
}
